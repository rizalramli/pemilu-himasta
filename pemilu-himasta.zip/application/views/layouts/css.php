<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/stisla/download_css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/stisla/download_css/all.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/stisla/download_css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/stisla/download_css/buttons.bootstrap4.min.css">

<!-- CSS Libraries -->

<!-- Template CSS -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/stisla/css/style.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/stisla/css/components.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/stisla/css/bootstrap-datetimepicker.min.css">